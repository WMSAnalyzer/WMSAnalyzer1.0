from fpdf import FPDF
from datetime import datetime

class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 14)
        self.cell(0, 10, "WMS — WhiteMilk Systems", ln=True, align="C")
        self.set_font("Arial", "", 10)
        self.cell(0, 10, f"Отчет от {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True, align="C")
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Страница {self.page_no()}", align="C")

def generate_pdf_report(shift_name, avg_milk, retries, zeros, output_dir="data"):
    filename = f"{output_dir}/WMS_Сводка_{shift_name}_{datetime.now().strftime('%Y-%m-%d_%H-%M')}.pdf"

    pdf = PDF()
    pdf.add_page()
    pdf.set_font("Arial", "", 12)

    pdf.cell(0, 10, f"Смена: {shift_name}", ln=True)
    pdf.cell(0, 10, f"Средний удой: {avg_milk:.2f} кг", ln=True)
    pdf.cell(0, 10, f"Повторы/ошибки: {retries}", ln=True)
    pdf.cell(0, 10, f"Нулевых надоев: {zeros}", ln=True)

    pdf.output(filename)
    print(f"[WMS] PDF отчет сохранен: {filename}")
    return filename
