import pandas as pd
from datetime import datetime

def export_to_excel(df, output_dir="data", shift_name="Без названия"):
    """
    Экспортирует DataFrame с анализом в Excel.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    filename = f"{output_dir}/WMS_Отчет_{shift_name}_{timestamp}.xlsx"

    try:
        df.to_excel(filename, index=False)
        print(f"[WMS] Отчет успешно сохранен: {filename}")
        return filename
    except Exception as e:
        print(f"[WMS] Ошибка сохранения Excel: {e}")
        return None
