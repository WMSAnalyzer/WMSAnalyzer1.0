import pandas as pd

def load_history(path="history/history.csv"):
    try:
        df = pd.read_csv(path)
        return df
    except FileNotFoundError:
        return pd.DataFrame(columns=["date", "shift", "avg_milk", "retries", "zeros"])

def forecast_next(df_history):
    """
    Простой прогноз: усреднение последних N смен по среднему удою.
    """
    if df_history.empty or "avg_milk" not in df_history.columns:
        return "Недостаточно данных для прогноза."

    recent = df_history.tail(10)
    mean_milk = recent["avg_milk"].mean()

    return f"📈 Прогноз на следующую смену: {mean_milk:.2f} кг (по последним {len(recent)} сменам)"
