import os
import pandas as pd
from datetime import datetime
from tkinter import filedialog, messagebox

from core.parser_dairyplan import parse_dairyplan_txt
from core.report_excel import export_to_excel
from core.report_pdf import generate_pdf_report
from core.forecast import load_history
from core.thresholds import calculate_thresholds
from core.risk_groups import load_animal_base, classify_risk

def run_analysis(shift_name="Без названия"):
    file_path = filedialog.askopenfilename(
        title="Выберите отчет DairyPlan (.txt)",
        filetypes=[("Текстовые файлы", "*.txt")]
    )

    if not file_path or not os.path.exists(file_path):
        messagebox.showwarning("Файл не выбран", "Пожалуйста, выберите файл отчета.")
        return

    try:
        df = parse_dairyplan_txt(file_path)

        cow_count = df["cow_id"].nunique()
        avg_milk = df["milk"].mean()
        zeros = df[df["milk"] == 0].shape[0]
        retries = len(df[df["status"].str.contains("RETRY|ERROR", na=False)])

        # Группы риска
        df_base = load_animal_base("data/base_template.xlsx")
        df_risk = classify_risk(df, df_base)

        # История
        save_to_history(shift_name, avg_milk, retries, zeros)

        # Экспорт
        export_to_excel(df, output_dir="data", shift_name=shift_name)
        generate_pdf_report(shift_name, avg_milk, retries, zeros)

        messagebox.showinfo(
            "Результаты анализа",
            f"Анализ завершён:\nЖивотных: {cow_count}\nСредний удой: {avg_milk:.2f} кг\nНулевых надоев: {zeros}"
        )

    except Exception as e:
        messagebox.showerror("Ошибка анализа", f"Ошибка: {e}")

def save_to_history(shift_name, avg_milk, retries, zeros, path="history/history.csv"):
    now = datetime.now().strftime("%Y-%m-%d")
    row = pd.DataFrame([{
        "date": now,
        "shift": shift_name,
        "avg_milk": round(avg_milk, 2),
        "retries": retries,
        "zeros": zeros
    }])

    if os.path.exists(path):
        df = pd.read_csv(path)
        df = pd.concat([df, row], ignore_index=True)
    else:
        df = row

    df.to_csv(path, index=False)

def generate_stall_map(df):
    stalls = df["stall"].unique()
    result = ""
    for stall in sorted(stalls):
        subset = df[df["stall"] == stall]
        if subset["milk"].mean() == 0 or subset["status"].str.contains("RETRY|ERROR", na=False).any():
            symbol = "🔴"
        elif subset["milk"].mean() < 5:
            symbol = "🟡"
        else:
            symbol = "🟢"
        result += f"{stall:>2}:{symbol}  "
        if stall % 6 == 0:
            result += "\n"
    return result
