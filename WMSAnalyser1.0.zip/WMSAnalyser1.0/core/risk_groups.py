import pandas as pd
from datetime import datetime

def load_animal_base(path="data/base_template.xlsx"):
    try:
        return pd.read_excel(path)
    except:
        return pd.DataFrame(columns=["cow_id", "calving_date"])

def classify_risk(df_milking, df_base):
    """
    Возвращает таблицу с пометками риска: 🔴, 🟡, 🟣, 🟢
    """
    merged = df_milking.merge(df_base, on="cow_id", how="left")
    merged["risk"] = "🟢"

    # 1. Нулевые удои
    merged.loc[merged["milk"] == 0, "risk"] = "🔴"

    # 2. Повторы или ошибки
    merged.loc[merged["status"].str.contains("RETRY|ERROR", na=False), "risk"] = "🟡"

    # 3. Свежая лактация (до 30 дней)
    if "calving_date" in merged.columns:
        merged["calving_date"] = pd.to_datetime(merged["calving_date"], errors="coerce")
        merged["days_in_lactation"] = (datetime.now() - merged["calving_date"]).dt.days
        merged.loc[merged["days_in_lactation"] <= 30, "risk"] = "🟣"

    return merged[["cow_id", "milk", "status", "risk", "days_in_lactation"]]
