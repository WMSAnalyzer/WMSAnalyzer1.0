# WMS — WhiteMilk Systems

Аналитическая система анализа доильного зала на базе данных DairyPlan.

## 🚀 Запуск

```bash
pip install -r requirements.txt
python main.py
