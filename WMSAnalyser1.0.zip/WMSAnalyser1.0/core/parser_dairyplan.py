import pandas as pd

def parse_dairyplan_txt(file_path):
    """
    Разбор .txt-файла отчета от DairyPlan.
    Формат: построчные записи с номером места, ID животного, удоем и статусом.
    Возвращает: DataFrame с колонками [stall, cow_id, milk, status].
    """
    data = []
    with open(file_path, encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) >= 4:
                try:
                    stall = int(parts[0])
                    cow_id = parts[1]
                    milk = float(parts[2])
                    status = parts[3]
                    data.append((stall, cow_id, milk, status))
                except ValueError:
                    continue
    df = pd.DataFrame(data, columns=["stall", "cow_id", "milk", "status"])
    return df
