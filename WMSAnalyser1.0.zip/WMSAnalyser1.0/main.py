import tkinter as tk
from core.analyzer import run_analysis
from core.forecast import load_history, forecast_next
from core.thresholds import calculate_thresholds
from core.analyzer import parse_dairyplan_txt, generate_stall_map

def start_app():
    window = tk.Tk()
    window.title("WMS — WhiteMilk Systems")
    window.geometry("900x600")

    # ==== Левая часть ====
    frame_left = tk.Frame(window, padx=10, pady=10)
    frame_left.pack(side="left", fill="y")

    label = tk.Label(frame_left, text="Анализ доильного зала", font=("Segoe UI", 14))
    label.pack(pady=10)

    tk.Label(frame_left, text="Название смены:").pack()
    shift_entry = tk.Entry(frame_left, width=25)
    shift_entry.insert(0, "Без названия")
    shift_entry.pack(pady=5)

    analyze_btn = tk.Button(
        frame_left,
        text="Анализировать",
        command=lambda: run_analysis(shift_entry.get()) or display_results(result_box, stall_map, shift_entry.get())
    )
    analyze_btn.pack(pady=10)

    # ==== Правая часть ====
    frame_right = tk.Frame(window, padx=10, pady=10)
    frame_right.pack(side="right", fill="both", expand=True)

    result_box = tk.Text(frame_right, height=25, width=60, font=("Consolas", 11))
    result_box.pack(fill="both", expand=True)

    map_label = tk.Label(frame_right, text="Карта доильного зала", font=("Segoe UI", 12, "bold"))
    map_label.pack(pady=5)

    stall_map = tk.Text(frame_right, height=10, font=("Consolas", 10))
    stall_map.pack(fill="x", padx=5, pady=5)

    window.mainloop()

def display_results(result_box, stall_map, shift_name):
    history = load_history()
    result_box.delete("1.0", "end")

    if history.empty:
        result_box.insert("end", "История пуста\n")
        return

    avg_series = history["avg_milk"]
    lower, upper = calculate_thresholds(avg_series, mode="percent", percent=15)
    last = history.iloc[-1]
    milk = last["avg_milk"]

    if milk < lower:
        color = "🔴"
        status = "Критически низкий удой"
    elif milk > upper:
        color = "🟢"
        status = "Отличный результат"
    else:
        color = "🟡"
        status = "Приемлемый уровень"

    forecast = forecast_next(history)

    result_box.insert("end", f"{color} Смена: {shift_name}\n")
    result_box.insert("end", f"  Средний удой: {milk:.2f} кг\n")
    result_box.insert("end", f"  Статус: {status}\n\n")
    result_box.insert("end", f"{forecast}\n")

    # Карта мест
    try:
        df = parse_dairyplan_txt("data/demo_report.txt")
        stall_summary = generate_stall_map(df)
        stall_map.delete("1.0", "end")
        stall_map.insert("end", stall_summary)
    except Exception as e:
        stall_map.insert("end", f"Ошибка карты: {e}")
