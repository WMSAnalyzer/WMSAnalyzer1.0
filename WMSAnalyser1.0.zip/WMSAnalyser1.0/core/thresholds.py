def calculate_thresholds(series, mode="sigma", k=1.5, percent=20):
    """
    Возвращает верхний и нижний порог отклонения на основе истории:
    - mode = 'sigma' → среднее ± k * std
    - mode = 'percent' → ± percent%
    """
    if series.empty:
        return (None, None)

    avg = series.mean()

    if mode == "sigma":
        std = series.std()
        lower = avg - k * std
        upper = avg + k * std
    elif mode == "percent":
        lower = avg * (1 - percent / 100)
        upper = avg * (1 + percent / 100)
    else:
        raise ValueError("Неверный режим порогов")

    return round(lower, 2), round(upper, 2)
